Realms of Ash CX v1.7
======================

NEW IN v1.7
-----------
Exploration pacing has been slowed down.

Why:
- In v1.6, area percentage could rise a little too quickly.
- Since keys only drop after 60% explored, the area progression should feel
  like a small journey, not something that happens almost immediately.

New pacing:
- Common explore events now usually add about 2-4%.
- Combat-related progress is lower.
- Hunt progress is lower.
- Hidden caches still give a slightly better exploration boost.
- The 60% key-drop rule is unchanged.

KEY RULE
--------
Keys for the next area cannot drop until the current area is at least 60%
explored.

ELITE SYSTEM
------------
Elite enemies remain in this version:
- Ash Wastes: about 8%
- Cinder Woods: about 10%
- Ruined Pass: about 12%
- Ember Keep: about 14%

AP SYSTEM
---------
- AP carries between fights.
- Attack recovers 1 AP.
- Defend recovers 1 AP.
- Special abilities spend AP.
- Resting restores AP to full.
- Ember Tonic restores 2-3 AP.

CONTROLS
--------
- 1-9 = menu actions
- ENTER = continue

SAVE NOTE
---------
v1.7 uses a new save format. Older saves from v1.6 and below will not load.
Start a new game for this version.

RealmsOfAsh_CX.prg.tns   ......Copy that file to your calculator and run it with Ndless.
